#!/bin/bash



srun -n 1 parabands.cplx.x &> parabands.inp.out
