#!/bin/bash

python3 script_pseudos.py
