#!/bin/bash



srun -n 128 pw.x  < wfnq.in &> wfnq.in.out 
