#!/bin/bash

./run.sh &> run.out &
