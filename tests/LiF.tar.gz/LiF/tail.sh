#!/bin/bash
tail -n100 -f $1
